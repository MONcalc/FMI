Proiectul este gata. Eventual voi mai face niște mici schimbări. 

Puteți să îmi transmiteți feedback-ul pe email sau ca issue pe repo, cum vă este mai ușor. 

Pentru a rula proiectul aveți nevoie de python. Navigați în directorul în care ați downloadat proiectul și folosiți comanda ”python3 -m http.server”. Intrați pe lin-ul dat de terminal și accesați base.html.

